<?php

use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\FrontController;
use App\Http\Controllers\Admin\AdminController;
use App\Http\Controllers\Admin\AdminPasswordController;
use App\Http\Controllers\Auth\UserRegisterController;
use App\Http\Controllers\Auth\LoginController;
use App\Http\Controllers\Auth\ForgotPasswordController;
use App\Http\Controllers\Auth\WaliDashboardController;
use App\Http\Controllers\Auth\RegisterController;

/*
|--------------------------------------------------------------------------
| Halaman Utama & Informasi
|--------------------------------------------------------------------------
*/

Route::get('/', [FrontController::class, 'index'])->name('home');
Route::get('/about', [FrontController::class, 'about'])->name('about');
Route::get('/contact', fn() => view('contact'))->name('contact');
Route::get('/santri', fn() => view('pages.santri'))->name('santri');

// Tes koneksi database
Route::get('/db-test', fn() => DB::select('SELECT version()'));

/*
|--------------------------------------------------------------------------
| ========================== BAGIAN USER ================================
|--------------------------------------------------------------------------
*/

/** REGISTER + VERIFIKASI EMAIL */
Route::get('register', [UserRegisterController::class, 'showRegisterForm'])->name('register');
Route::post('register', [UserRegisterController::class, 'register'])->name('register.submit');
Route::get('verify-email/{token}', [UserRegisterController::class, 'verifyEmail'])->name('verify.email');
Route::get('/register', [RegisterController::class, 'showRegistrationForm'])->name('register');
Route::post('/register', [RegisterController::class, 'register'])->name('register.submit');

/** LOGIN USER */
Route::get('login', [LoginController::class, 'showLoginForm'])->name('login');
Route::post('login', [LoginController::class, 'login'])->name('login.submit');
Route::post('logout', [LoginController::class, 'logout'])->name('logout');

/** FORGOT PASSWORD USER */
Route::controller(ForgotPasswordController::class)->group(function () {
    Route::get('forgot-password', 'showLinkRequestForm')->name('password.request');
    Route::post('forgot-password', 'sendResetLinkEmail')->name('password.email');
    Route::get('reset-password/{token}', 'showResetForm')->name('password.reset');
    Route::post('reset-password', 'reset')->name('password.update');
});

Route::middleware(['auth', 'role:Wali'])->group(function () {
    Route::get('/wali/dashboard', [WaliDashboardController::class, 'index'])->name('wali.dashboard');
});


/*
|--------------------------------------------------------------------------
| ========================== BAGIAN ADMIN ================================
|--------------------------------------------------------------------------
*/

Route::prefix('admin')->group(function () {
    // LOGIN ADMIN
    Route::get('/login', [AdminController::class, 'login'])->name('admin_login');
    Route::post('/login', [AdminController::class, 'login_submit'])->name('admin_login_submit');
    Route::get('/logout', [AdminController::class, 'logout'])->name('admin_logout');

    // FORGOT PASSWORD ADMIN
    Route::controller(AdminPasswordController::class)->group(function () {
        Route::get('forgot-password', 'showForgotForm')->name('admin_forget_password');
        Route::post('forgot-password', 'sendResetLink')->name('admin_forget_password_submit');
        Route::get('reset-password/{token}', 'showResetForm')->name('admin_reset_password');
        Route::post('reset-password', 'resetPassword')->name('admin_reset_password_submit');
    });

    // DASHBOARD ADMIN (akses hanya jika sudah login)
    Route::middleware('admin')->group(function () {
        Route::get('/dashboard', [AdminController::class, 'dashboard'])->name('admin_dashboard');
    });
});
