<?php

namespace App\Http\Controllers\Auth; // huruf A besar, penting!

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;
use App\Models\User;

class RegisterController extends Controller
{
    // 🧱 Menampilkan halaman register
    public function showRegistrationForm()
    {
        return view('auth.register');
    }

    // 🧩 Menangani proses register
    public function register(Request $request)
    {
        // ✅ Validasi data input
        $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|email|unique:users,email',
            'password' => 'required|confirmed|min:6',
            'phone' => 'required|string|max:20',
            'id_role' => 'required|integer',
            'secret_code' => 'nullable|string',
        ]);

        // ✅ Validasi kode rahasia (khusus Degur dan Pengurus)
        if ($request->id_role == 6 && $request->secret_code !== 'DEGUR2025') {
            return back()->withErrors(['secret_code' => 'Kode Degur tidak valid.'])->withInput();
        }

        if ($request->id_role == 7 && $request->secret_code !== 'PENGURUS2025') {
            return back()->withErrors(['secret_code' => 'Kode Pengurus tidak valid.'])->withInput();
        }

        // ✅ Simpan user baru
        User::create([
            'name' => $request->name,
            'email' => $request->email,
            'password' => Hash::make($request->password),
            'phone' => $request->phone,
            'id_role' => $request->id_role,
            'verification_token' => Str::random(64),
            'status' => 0,
        ]);

        // ✅ Arahkan ke halaman login
        return redirect()->route('login')->with('success', 'Registrasi berhasil! Silakan login.');
    }
}